#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
#include "mathv1.h"
#include "mytools.h"

int main(){
		int option, num1, num2;
		double result;
		char operation;
	 
    do{
		system("cls");
		drawDBox(0, 4, 75, 12);
//		drawDBox(30, 4, 90, 12);
    	menu();
    	
    	gotoxy(50, 12);
    	scanf(" %c", &operation);
    	
    	gotoxy(0, 15);
    	drawSBox(13,15,60,20);
    	
	    if(operation == '+' || operation == '-' || operation == '*' || operation == '/' || operation == '%'){
			outString(15,17,"\033[1;32mEnter first number: \033[1;36m");
			scanf("%d", &num1);
			outString(15,18,"\033[1;36mEnter second number: \033[1;36m");
			scanf("%d", &num2);
			
			switch(operation){
				case '+':
					result = sum(num1, num2);
					break;
				case '-':
					result = diff(num1, num2);
					break;
				case '*':
					result = prod(num1, num2);
					break;
				case '/':
					result = quo(num1, num2);
					break;
				case '%':
					result = mod(num1, num2);
					break;
			}
			
			switch(operation){
				case '+':
				case '-':
				case '*':
				case '/':
				case '%':
					gotoxy(15,19);
					printf("\033[1;33mResult is: %.2lf\033[1;0m\n", result);
					break;
			}
			
			gotoxy(13,23);
			printf("\033[1;36mPress 1 to continue and 0 to exit the program... ");
			option = getche() - '0';
			printf("\n\n");
	}
		else {
			gotoxy(15,17);
			printf("\033[1;33mInvalid Operation Try Again...\033[1;0m");
			
			gotoxy(13,23);
			printf("\033[1;36mPress 1 to continue and 0 to exit the program... ");
			option = getche() - '0';
			printf("\n\n");
		}
	}
	while(option == 1);
	
	return 0;
}