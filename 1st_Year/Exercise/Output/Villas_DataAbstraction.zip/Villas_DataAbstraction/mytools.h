#include <conio.h>
#include <stdio.h>
#include <string.h>

#include <process.h>
#include <iostream.h>
#include <windows.h>

void clrscr();
void gotoxy(int x, int y)
//void gotoxy(short x, short y);
void center(int row, char str[]);
void outString(int col, int row, char str[]);
void drawSBox(int x1, int y1, int x2, int y2);
void drawDBox(int x1, int y1, int x2, int y2);
void menu();