#include <stdio.h>
int sum(int x, int y);
int diff(int x, int y);
long int prod(int x, int y);
float quo(int x, int y);
int mod(int x, int y);