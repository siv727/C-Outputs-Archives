#include <stdio.h>
#include <string.h>
#include <windows.h>

void gotoxy(short x, short y){
    COORD pos = {x, y};
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos); 
}

void center(int row, char str[]){
    int col = (80-strlen(str))/2;
    gotoxy(col, row);
    printf("%s", str);
}

void outString(int col, int row, char str[]){
    gotoxy(col, row);
    printf("%s", str);
}

void drawSBox(int x1, int y1, int x2, int y2){
	int i;
	printf("\033[1;36m");
	gotoxy(x1, y1);
	putchar(201);
	gotoxy(x1, y2+1);
	putchar(200);
	for(i = x1+1; i <= x2-1; i++){
		gotoxy(i, y1);
		putchar(205);
		gotoxy(i, y2+1);
		putchar(205);
	}
	for(i = y1+1; i <= y2; i++){
		gotoxy(x1, i);
		putchar(186);
		gotoxy(x2, i);
		putchar(186);
	}
	gotoxy(x2, y1);
	putchar(187);
	gotoxy(x2, y2+1);
	putchar(188);
}

void drawDBox(int x1, int y1, int x2, int y2){
	int i;
	printf("\033[1;36m");
	gotoxy(x1, y1);
	putchar(201);
	gotoxy(x1, y2+1);
	putchar(200);
	for(i = x1+1; i <= x2-1; i++){
		gotoxy(i, y1);
		putchar(205);
		gotoxy(i, y2+1);
		putchar(205);
	}
	for(i = y1+1; i <= y2; i++){
		gotoxy(x1, i);
		putchar(186);
		gotoxy(x2, i);
		putchar(186);
	}
	gotoxy(x2, y1);
	putchar(187);
	gotoxy(x2, y2+1);
	putchar(188);
}

void menu(){
	center(1, "\033[1;36mPROGRAMMING 2");
    center(2, "\033[1;32mFUNCTION IMPLEMENTATION");
    center(3, "\033[1;36mw/ DATA ABSTRACTION");
    center(5, "\033[1;31m~~~~~ BASIC MATH OPERATIONS ~~~~~");
    center(6, "\033[1;32mMODULO [%]");
    center(7, "\033[1;36mDIVIDE [/]");
    center(8, "\033[1;31mMULTIPLY [*]");
    center(9, "\033[1;35mADDITION [+]");
    center(10, "\033[1;33mSUBTRACTION [-]");
    center(11, "");
    center(12, "\033[1;36mEnter math operator[%/*+-]: ");
}
